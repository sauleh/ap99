﻿using System;
using System.IO;

namespace A8.OOCalculator
{
    public class AddOperator : BinaryOperator
    {
        public AddOperator(TextReader reader)
        {
            throw new NotImplementedException();
        }

        public override string OperatorSymbol => throw new NotImplementedException();

        public override double Evaluate() => throw new NotImplementedException();
    }
}