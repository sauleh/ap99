﻿namespace A8.OOCalculator
{
    public interface IOperator
    {
        string OperatorSymbol { get; }
    }
}